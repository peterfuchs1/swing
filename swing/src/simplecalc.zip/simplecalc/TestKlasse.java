/**
 * 
 */
package simplecalc;

/**
 * @author Walter Rafeiner-Magor
 *
 */
public class TestKlasse {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 new MyFrame();
	}


}
